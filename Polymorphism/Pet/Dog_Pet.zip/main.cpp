#include "Dog.h"

int main(){
    Pet vpet("Maviş");
    vpet.print();
    Dog vdog("Tomas","Husky");
    vdog.print();
    Pet *ppet=new Pet("Sarı");
    ppet->print();
    Dog *pdog=new Dog("Garip","Alman kurdu");
    pdog->print();

    ppet=pdog;//Slicing problem fixed POINTER
    vpet=vdog;//slicing problem occured NORMAL
    ppet->print();
    vpet.print();

    return 0;
}
